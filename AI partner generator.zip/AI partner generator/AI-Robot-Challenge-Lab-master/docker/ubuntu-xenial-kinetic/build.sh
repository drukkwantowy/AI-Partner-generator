#!/bin/bash
export DEBIAN_FRONTEND="noninteractive"
sudo docker build -t ubuntu1604_sawyer . --no-cache
